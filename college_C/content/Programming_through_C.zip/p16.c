#include<stdio.h>
int main()
{
	int  i = 1;
	
	while ( 2)
	{
	printf(" %d ",i++);
	i++;
	}
	
	
	printf(" %d ", i);
}

	
