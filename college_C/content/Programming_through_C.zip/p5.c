#include<stdio.h>
void main()
{
	short int a = 32770;
	printf("%d ", a);

}
