#include<stdio.h>
void main()
{
	int a=3;
	float b = 10.3;
	printf("%d", b%a);


}
