#include<stdio.h>
void main()
{			  	
	char str1[20];  
	int len=0;
	printf (" enter the string ");
	scanf("%s", str1);
	while(str1[len] != '\0')
		len++;
	
	int v=0;
	for(i=0;i<len;i++)
	{
		if ( str[i] == 'A' || str[i] == 'a' .........................)
		v++;
	}	
		
		
	printf(" length of the string is %d ", len);
}
